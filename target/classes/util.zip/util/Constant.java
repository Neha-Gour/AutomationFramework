package com.RCS.util;

public class Constant {
	public static long PAGE_LOAD_TIMEOUT;
	public static long IMPLICIT_WAIT;

	static {
		Constant.PAGE_LOAD_TIMEOUT = 3000;
		Constant.IMPLICIT_WAIT = 3000;
	}
}

