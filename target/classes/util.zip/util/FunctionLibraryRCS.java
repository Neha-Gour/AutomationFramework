// Common Function For RCS Application
package com.RCS.util;

import com.RCS.base.TestBase;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.io.File;

public class FunctionLibraryRCS extends TestBase {
	// Object Repository
	@FindBy( id = "username" )
	WebElement username;

	@FindBy( id = "password" )
	WebElement password;

	@FindBy( xpath = "//input[@type='submit']" )
	WebElement loginBtn;

	public FunctionLibraryRCS() {
		PageFactory.initElements( driver, this );
	}

	public static void scrollbottom() {
		( ( JavascriptExecutor ) driver ).executeScript( "window.scrollTo(0, document.body.scrollHeight)" );

	}

	//Function to get downloaded path		
	public static String getDownloadsPath() {

		String downloadPath = System.getProperty( "user.home" );
		File file = new File( downloadPath + "/Downloads/" );
		return file.getAbsolutePath();
	}

	public static boolean isFileDownloaded( String downloadPath, String fileName ) {
		File dir = new File( downloadPath );
		File[] dir_contents = dir.listFiles();

		if( dir_contents != null ) {
			for( File dir_content : dir_contents ) {
//				System.out.println(dir_content.getName());
				if( dir_content.getName().contains( fileName ) )
					return true;
			}
		}

		return false;
	}


}
