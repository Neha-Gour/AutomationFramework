package com.RCS.util;

import com.RCS.base.TestBase;
import com.squareup.javapoet.AnnotationSpec;
import com.squareup.javapoet.FieldSpec;
import com.squareup.javapoet.JavaFile;
import com.squareup.javapoet.TypeSpec;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import javax.lang.model.element.Modifier;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public class 
JavaPoetPageWebElement extends TestBase{

	public static WebElement driver;
	public static String pageName;

	public static void getAllWebElement( WebDriver driver ) throws IOException {
		List<WebElement> webElementList = driver.findElements( By.tagName( "*" ) );
		if (driver.findElement(By.cssSelector(".m-1.text-primary")).isDisplayed()) {
			pageName = driver.findElement(By.cssSelector(".m-1.text-primary")).getText();
			System.out.println(pageName);}
		
		else 
		{
			pageName = driver.findElement(By.cssSelector(".text-center.text-success")).getText();
			System.out.println(pageName);
		pageName.replaceAll("//s+","");
		pageName = pageName+"Page";
		
		System.out.println(pageName);
		
		TypeSpec.Builder objectRepository = TypeSpec.classBuilder( "RCSObjectRepository" ).addModifiers( Modifier.PUBLIC );
		TypeSpec.Builder loginPage = TypeSpec.classBuilder( pageName ).addModifiers( Modifier.PUBLIC, Modifier.STATIC ).superclass( TestBase.class );

		webElementList = webElementList
				.stream()
				.filter( webElement -> Objects.nonNull( webElement.getAttribute( "id" ) )
						&& Objects.nonNull( webElement.getAttribute( "name" ) )
						&& Objects.nonNull( webElement.getAttribute( "class" ) ) )
				.collect( Collectors.toList() );
		for( WebElement webElement : webElementList ) {
			ObjectLocator objLocator = getElementName( webElement );
			loginPage.addField(
					FieldSpec.builder( WebElement.class, objLocator.getFieldName().replaceAll( "[^a-zA-Z0-9]+", "_" ) )
							.addAnnotation( AnnotationSpec.builder( FindBy.class ).addMember( objLocator.getLocator(), "$S", objLocator.getElementName() ).build() )
							.addModifiers( Modifier.PUBLIC, Modifier.STATIC )
							.build() );
		}

		objectRepository.addType( loginPage.build() );
		JavaFile javaFile = JavaFile.builder( "com.RCS.model", objectRepository.build() ).build();
		File file = new File( "src/main/java" );
		javaFile.writeTo( file );
		}
	}

	public static ObjectLocator getElementName( WebElement webElement ) {
		if( Objects.nonNull( webElement.getAttribute( "id" ) ) && !"".equals( webElement.getAttribute( "id" ) ) ) {
			return new ObjectLocator( "id", webElement.getAttribute( "id" ) );
		}
		if( Objects.nonNull( webElement.getAttribute( "name" ) ) && !"".equals( webElement.getAttribute( "name" ) ) ) {
			return new ObjectLocator( "name", webElement.getAttribute( "name" ) );
		}
		if( Objects.nonNull( webElement.getAttribute( "class" ) ) && !"".equals( webElement.getAttribute( "class" ) ) ) {
			return new ObjectLocator( "class", webElement.getAttribute( "class" ) );
		}
		if( Objects.nonNull( webElement.getTagName() ) ) {
			return new ObjectLocator( "tag", webElement.getTagName() );
		}
		return new ObjectLocator( "", "element" );
	}

}
