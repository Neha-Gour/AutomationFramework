package com.RCS.util;

import org.apache.log4j.Logger;

public class LogUtil {

	private static Logger Log;

	static {
		LogUtil.Log = Logger.getLogger( LogUtil.class.getName() );
	}

	public static void startTestCase( final String sTestCaseName ) {
		LogUtil.Log.info( "****************************************************************************************" );
		LogUtil.Log.info( "****************************************************************************************" );
		LogUtil.Log.info( "$$$$$$$$$$$$$$$$$$$$$                 " + sTestCaseName + "       $$$$$$$$$$$$$$$$$$$$$$$$$" );
		LogUtil.Log.info( "****************************************************************************************" );
		LogUtil.Log.info( "****************************************************************************************" );
	}

	public static void endTestCase( final String sTestCaseName ) {
		LogUtil.Log.info( "XXXXXXXXXXXXXXXXXXXXXXX             -E---N---D-             XXXXXXXXXXXXXXXXXXXXXX" );
		LogUtil.Log.info( "X" );
		LogUtil.Log.info( "X" );
	}

	public static void info( final String message ) {
		LogUtil.Log.info( message );
	}

	public static void warn( final String message ) {
		LogUtil.Log.warn( message );
	}

	public static void error( final String message ) {
		LogUtil.Log.error( message );
	}

	public static void fatal( final String message ) {
		LogUtil.Log.fatal( message );
	}

	public static void debug( final String message ) {
		LogUtil.Log.debug( message );
	}
}
