package com.RCS.util;

import com.RCS.base.TestBase;

public class ObjectLocator extends TestBase {
	String locator;
	String elementName;

	String fieldName;

	public ObjectLocator(  String locator, String elementName ) {
		this.fieldName = new String( elementName );
		switch( locator ) {
			case "tag":
				locator = "tagName";
				break;
			case "class":
				locator = "css";
				elementName = "." + elementName.replaceAll( "\\s", "." );
				break;
		}
		this.locator = locator;
		this.elementName = elementName;
	}

	public String getLocator() {
		return locator;
	}

	public String getElementName() {
		return elementName;
	}

	public String getFieldName() {
		return fieldName;
	}
}
