package com.RCS.util;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;
import java.util.Properties;

public class PageWebElement {

	public static Properties prop;
	public static String webElement_value;
	public static WebElement driver;
	public static String pageTitle;

	public static void getAllWebElement( WebDriver driver ) throws IOException {

		// Below will return a list of all elements in web page

		List<WebElement> webElementList = driver.findElements( By.tagName( "*" ) );
//		System.err.println(webEleList.size());
		// get the driver page name
//		pageTitle = driver.getTitle();
//		System.out.println(pageTitle);
		PageWebElement.prop = new Properties();
//
		final OutputStream ORfile = new FileOutputStream(
				System.getProperty( "user.dir" ) + "/src/main/resources/ObjectRepository.properties" );
//		 PageWebElement.prop.lo(ORfile);
//		ArrayList<Object> all_elements_text = new ArrayList<Object>();

		List<WebElement> allInputElements = driver.findElements( By.tagName( "input" ) );
		for( int i = 0; i < webElementList.size(); i++ ) {
			String tagname = webElementList.get( i ).getTagName();
			System.out.println( tagname );
		}
		String elementAttribute;
		if( webElementList.size() != 0 ) {
			String elementName;
			System.out.println( webElementList.size() + " Elements found by TagName \n" );
//				
			for( WebElement inputElement : webElementList ) {

				// String WebElementXpath;
				if( inputElement.getAttribute( "id" ) != null ) {
					webElement_value = inputElement.getAttribute( "id" );
					elementAttribute = "id";
					String placeholder = inputElement.getAttribute( "placeholder" );

					String tagname = inputElement.getTagName();
					if( placeholder != null )
						elementName = tagname + placeholder;
					else
						elementName = tagname;

					System.out.println( elementName + " " + elementAttribute + webElement_value );
					prop.put( elementName + " " + elementAttribute, webElement_value );
//					java.add()
//					
					continue;

				} else if( inputElement.getAttribute( "name" ) != null ) {
					webElement_value = inputElement.getAttribute( "name" );
					elementAttribute = "name";
					String placeholder = inputElement.getAttribute( "placeholder" );
					String tagname = inputElement.getTagName();
					if( placeholder != null )
						elementName = tagname + placeholder;
					else
						elementName = tagname;

					System.out.println( elementName + " " + elementAttribute + webElement_value );
					prop.put( elementName + " " + elementAttribute, webElement_value );

					continue;
				} else if( inputElement.getAttribute( "class" ) != null ) {
					webElement_value = inputElement.getAttribute( "class" );
					elementAttribute = "class";
					String placeholder = inputElement.getAttribute( "placeholder" );
					String tagname = inputElement.getTagName();
					if( placeholder != null )
						elementName = tagname + placeholder;
					else
						elementName = tagname;
					System.out.println( elementName + " " + elementAttribute + webElement_value );
					prop.put( elementName + " " + elementAttribute, webElement_value );
//					
					continue;

				} else if( inputElement.getAttribute( "name" ) != null ) {
					webElement_value = inputElement.getAttribute( "name" );
					elementAttribute = "name";
					String placeholder = inputElement.getAttribute( "placeholder" );
					String tagname = inputElement.getTagName();
					if( placeholder != null )
						elementName = tagname + placeholder;
					else
						elementName = tagname;

					System.out.println( elementName + " " + elementAttribute + webElement_value );
					prop.put( elementName + " " + elementAttribute, webElement_value );
//					
					continue;
				} else

					webElement_value = getAbsoluteXPath( inputElement );
				elementAttribute = "xpath";
			}
			prop.store( ORfile, "Appication Runtime generated Object Repository" );

		}

	}


	// Xpath Function
	public static String getAbsoluteXPath( WebElement element ) {
		return ( String ) ( ( JavascriptExecutor ) driver )
				.executeScript( "function absoluteXPath(element) {" + "var comp, comps = [];" + "var parent = null;"
						+ "var xpath = '';" + "var getPos = function(element) {" + "var position = 1, curNode;"
						+ "if (element.nodeType == Node.ATTRIBUTE_NODE) {" + "return null;" + "}"
						+ "for (curNode = element.previousSibling; curNode; curNode = curNode.previousSibling) {"
						+ "if (curNode.nodeName == element.nodeName) {" + "++position;" + "}" + "}" + "return position;"
						+ "};" +

						"if (element instanceof Document) {" + "return '/';" + "}" +

						"for (; element && !(element instanceof Document); element = element.nodeType == Node.ATTRIBUTE_NODE ? element.ownerElement : element.parentNode) {"
						+ "comp = comps[comps.length] = {};" + "switch (element.nodeType) {" + "case Node.TEXT_NODE:"
						+ "comp.name = 'text()';" + "break;" + "case Node.ATTRIBUTE_NODE:"
						+ "comp.name = '@' + element.nodeName;" + "break;" + "case Node.PROCESSING_INSTRUCTION_NODE:"
						+ "comp.name = 'processing-instruction()';" + "break;" + "case Node.COMMENT_NODE:"
						+ "comp.name = 'comment()';" + "break;" + "case Node.ELEMENT_NODE:"
						+ "comp.name = element.nodeName;" + "break;" + "}" + "comp.position = getPos(element);" + "}" +

						"for (var i = comps.length - 1; i >= 0; i--) {" + "comp = comps[i];"
						+ "xpath += '/' + comp.name.toLowerCase();" + "if (comp.position !== null) {"
						+ "xpath += '[' + comp.position + ']';" + "}" + "}" +

						"return xpath;" +

						"} return absoluteXPath(arguments[0]);", element );
	}

	public List<WebElement> findElements( String locator, long... timeOut ) {

		if( timeOut.length == 1 && timeOut[0] == 0 ) {
			return driver.findElements( getBy( locator ) );
		}
//        } else if (timeOut.length == 1 && timeOut[0] > 0) {
//            waitForPresent(locator, timeOut[0]);
//        } else {
//            waitForPresent(locator);
//        }
//    } catch (Exception e) {
		return null;

//    return driver.findElements(getBy(locator));
	}

	private By getBy( String locator ) {
//    locator = prop.getProperty(key, defaultValue)).getString(locator, locator);
		String[] parts = locator.split( "=", 2 );
		By by = null;
		switch( parts[0].trim() ) {
			case "xpath":
				by = By.xpath( parts[1] );
				break;
			case "name":
				by = By.name( parts[1] );
				break;
			case "link":
				by = By.linkText( parts[1] );
				break;
			case "id":
				by = By.id( parts[1] );
				break;
			case "css":
				by = By.cssSelector( parts[1] );
				break;
			default:
				throw new RuntimeException( "invalid locator" );
		}
		return by;
	}

}
