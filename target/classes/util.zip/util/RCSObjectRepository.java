package com.RCS.util;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class RCSObjectRepository {
  @FindBy(
      tagName = "meta"
  )
  public WebElement meta;

  @FindBy(
      name = "viewport"
  )
  public WebElement viewport;

  @FindBy(
      tagName = "img"
  )
  public WebElement img;

  @FindBy(
      id = "loginForm"
  )
  public WebElement loginForm;

  @FindBy(
      name = "csrfmiddlewaretoken"
  )
  public WebElement csrfmiddlewaretoken;

  @FindBy(
      id = "username"
  )
  public WebElement username;

  @FindBy(
      id = "password"
  )
  public WebElement password;

  @FindBy(
      className = "forgot-password"
  )
  public WebElement forgot_password;

  @FindBy(
      className = "btn btn-login btn-outline-success mx-auto inputshadow"
  )
  public WebElement btn_btn_login_btn_outline_success_mx_auto_inputshadow;
}
