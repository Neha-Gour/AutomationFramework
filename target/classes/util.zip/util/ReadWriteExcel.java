package com.RCS.util;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class ReadWriteExcel {
	public static XSSFSheet ExcelWSheet;
	public static XSSFWorkbook ExcelWBook;
	private static Cell Cell;
	private static Row Row;


	public static void setExcelFile( final String Filename, final int SheetNumber ) throws Exception {
		System.out.println( "Excel Data" );
		System.out.println( System.getProperty( "user.dir" ) );

		try {
			//String path1="\\src\\main\\testdata\\RCSTestdata.xlsx";
			final FileInputStream ExcelFile = new FileInputStream( System.getProperty( "user.dir" ) + "/src/main/java/com/RCS/testdata/" + Filename );
			ReadWriteExcel.ExcelWBook = new XSSFWorkbook( ExcelFile );
			ReadWriteExcel.ExcelWSheet = ReadWriteExcel.ExcelWBook.getSheetAt( SheetNumber );
		} catch( Exception e ) {
			throw e;
		}
	}

	public static String getCellData( final int RowNum, final int ColNum ) throws Exception {
		final DataFormatter formatter = new DataFormatter();
		try {
			ReadWriteExcel.Cell = ReadWriteExcel.ExcelWSheet.getRow( RowNum ).getCell( ColNum );
			final String CellData = formatter.formatCellValue( ReadWriteExcel.Cell );
			return CellData;
		} catch( Exception e ) {
			e.printStackTrace();
			return "";
		}
	}

	public static void setCellData( final String Result, final int RowNum, final int ColNum, final String Filename ) throws Exception {
		try {
			ReadWriteExcel.Row = ReadWriteExcel.ExcelWSheet.getRow( RowNum );
			ReadWriteExcel.Cell = ReadWriteExcel.Row.getCell( ColNum );
			if( ReadWriteExcel.Cell == null ) {
				( ReadWriteExcel.Cell = ReadWriteExcel.Row.createCell( ColNum ) ).setCellValue( Result );
			} else {
				ReadWriteExcel.Cell.setCellValue( Result );
			}
			final FileOutputStream fileOut = new FileOutputStream( System.getProperty( "user.dir" ) + "/src/main/java/com/kizora/testdata/" + Filename );
			ReadWriteExcel.ExcelWBook.write( fileOut );
			fileOut.flush();
			fileOut.close();
		} catch( Exception e ) {
			throw e;
		}
	}
}
