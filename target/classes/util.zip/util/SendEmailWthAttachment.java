package com.RCS.util;

import javax.activation.*;
import javax.mail.*;
import javax.mail.internet.*;
import java.util.*;

/**
 * This class is used to send email with attachment.
 * 
 * @author w3spoint
 */
public class SendEmailWthAttachment {
	final String senderEmailId = "rizwan.khan@kizora.com";
	final String senderPassword = "pmndjntmmyywkrhh";
	final String emailSMTPserver = "smtpout.secureserver.net";

	public SendEmailWthAttachment(String receiverEmail, String subject, String messageText, String fileName,
			String filePath) {
		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.host", "smtp.office365.com");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.port", "587");
		props.put("password", senderPassword);
		props.put("mail.smtp.user", senderEmailId);
		props.put("mail.smtp.ssl.protocols", "TLSv1.2");

		try {
			Authenticator auth = new SMTPAuthenticator();
			Session session = Session.getInstance(props, auth);
			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress(senderEmailId));
			message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(receiverEmail));
			message.setSubject(subject);
			MimeBodyPart messageBodyPart1 = new MimeBodyPart();
			messageBodyPart1.setText(messageText);
			MimeBodyPart messageBodyPart2 = new MimeBodyPart();
			DataSource source = new FileDataSource(filePath);
			messageBodyPart2.setDataHandler(new DataHandler(source));
			messageBodyPart2.setFileName(fileName);
			Multipart multipart = new MimeMultipart();
			multipart.addBodyPart(messageBodyPart1);
			multipart.addBodyPart(messageBodyPart2);
			message.setContent(multipart);
			message.setText(messageText);
			Transport.send(message);
			System.out.println("Email send successfully.");
		} catch (Exception e) {

			System.err.println("Error in sending email.");
		}
	}

	private class SMTPAuthenticator extends javax.mail.Authenticator {
		public PasswordAuthentication getPasswordAuthentication() {
			return new PasswordAuthentication(senderEmailId, senderPassword);
		}
	}

	public static void main(String[] args) {
		new SendEmailWthAttachment("kirti.vidhani@kizora.com", "RCS Automation Result Report",
				"Hi,\n\n This is a RCS Automation Result Report email " + "with attachment.",
				"C:\\Users\\KirtiVidhani\\Selenium Workspace\\RCS_Automation_POC\\07-July-2022-02-06.zip",
				"07-July-2022-02-06.zip");
	}
}