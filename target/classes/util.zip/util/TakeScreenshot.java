package com.RCS.util;


import com.RCS.base.TestBase;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class TakeScreenshot extends TestBase {
	public static String getScreenshot( final WebDriver driver, final String screenshotName ) throws IOException {
		final String dateName = new SimpleDateFormat( "yyyyMMddhhmmss" ).format( new Date() );
		final TakesScreenshot ts = ( TakesScreenshot ) driver;
		final File source = ts.getScreenshotAs( OutputType.FILE );
		final String destination = "./ExtentReports/FailedTestcaseScreenshots/" + screenshotName + dateName + ".png";
		final File finalDestination = new File( destination );
		FileUtils.copyFile( source, finalDestination );
		return destination;
	}
}

